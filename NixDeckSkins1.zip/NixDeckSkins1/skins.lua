SMODS.Atlas({
	key = "modicon",
	path = "modicon.png",
	px = 32,
	py = 32
})

-- low contrast collection
local atlas_lc = SMODS.Atlas {
	key = "skin_lc",
	path = "skin_lc.png",
	px = 71,
	py = 95,
}

local atlas2_lc = SMODS.Atlas {
	key = "skin2_lc",
	path = "skin2_lc.png",
	px = 71,
	py = 95,
}

local atlas3_lc = SMODS.Atlas {
	key = "skin3_lc",
	path = "skin3_lc.png",
	px = 71,
	py = 95,
}

local atlas4_lc = SMODS.Atlas {
	key = "skin4_lc",
	path = "skin4_lc.png",
	px = 71,
	py = 95,
}

local icon_lc = SMODS.Atlas {
	key = "icon_lc",
	path = "icon_lc.png",
	px = 18,
	py = 18,
}

local icon2_lc = SMODS.Atlas {
	key = "icon2_lc",
	path = "icon2_lc.png",
	px = 18,
	py = 18,
}

local icon3_lc = SMODS.Atlas {
	key = "icon3_lc",
	path = "icon3_lc.png",
	px = 18,
	py = 18,
}

local icon4_lc = SMODS.Atlas {
	key = "icon4_lc",
	path = "icon4_lc.png",
	px = 18,
	py = 18,
}


-- high contrast collection
local atlas_hc = SMODS.Atlas {
	key = "skin_hc",
	path = "skin_hc.png",
	px = 71,
	py = 95,
}

local atlas2_hc = SMODS.Atlas {
	key = "skin2_hc",
	path = "skin2_hc.png",
	px = 71,
	py = 95,
}

local atlas3_hc = SMODS.Atlas {
	key = "skin3_hc",
	path = "skin3_hc.png",
	px = 71,
	py = 95,
}

local atlas4_hc = SMODS.Atlas {
	key = "skin4_hc",
	path = "skin4_hc.png",
	px = 71,
	py = 95,
}

local icon_hc = SMODS.Atlas {
	key = "icon_hc",
	path = "icon_hc.png",
	px = 18,
	py = 18,
}

local icon2_hc = SMODS.Atlas {
	key = "icon2_hc",
	path = "icon2_hc.png",
	px = 18,
	py = 18,
}

local icon3_hc = SMODS.Atlas {
	key = "icon3_hc",
	path = "icon3_hc.png",
	px = 18,
	py = 18,
}

local icon4_hc = SMODS.Atlas {
	key = "icon4_hc",
	path = "icon4_hc.png",
	px = 18,
	py = 18,
}

-- next time i do the above ima just use a for loop, im pretty sure i could have anyway
-- this works fine for me tho :p

SMODS.DeckSkin {
	key = "nixandco",
	suit = "Spades",
	loc_txt = "Nix's Roster",
	palettes = {
		{
			key = 'lc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas_lc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon_lc.key,
			},
		},
		{
			key = 'hc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas_hc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon_hc.key,
			},
		},
	},
}

SMODS.DeckSkin {
	key = "childrenders",
	suit = "Diamonds",
	loc_txt = "The Childrenders",
	palettes = {
		{
			key = 'lc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas2_lc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon2_lc.key,
			},
		},
		{
			key = 'hc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas2_hc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon2_hc.key,
			},
		},
	},
}

SMODS.DeckSkin {
	key = "miketriodeltarune",
	suit = "Clubs",
	loc_txt = "The Mike Squad",
	palettes = {
		{
			key = 'lc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas3_lc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon3_lc.key,
			},
		},
		{
			key = 'hc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas3_hc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon3_hc.key,
			},
		},
	},
}

SMODS.DeckSkin {
	key = "freddy",
	suit = "Hearts",
	loc_txt = "Order and Chaos",
	palettes = {
		{
			key = 'lc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas4_lc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon4_lc.key,
			},
		},
		{
			key = 'hc',
			ranks = {'2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', "King", "Ace",},
			display_ranks = {"King", "Queen", "Jack",},
			atlas = atlas4_hc.key,
			pos_style = 'suit',
			suit_icon = {
				atlas = icon4_hc.key,
			},
		},
	},
}


